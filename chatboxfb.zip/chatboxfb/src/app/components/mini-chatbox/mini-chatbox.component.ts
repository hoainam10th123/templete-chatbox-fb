import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-mini-chatbox',
  templateUrl: './mini-chatbox.component.html',
  styleUrls: ['./mini-chatbox.component.css']
})
export class MiniChatboxComponent implements OnInit {
  @Input() user: any;
  @Output() restoreChatBox = new EventEmitter();
  @Output() removeChatBox = new EventEmitter();
  isHidden = false;

  constructor() { }

  ngOnInit(): void {
  }

  restoreUser(){
    this.restoreChatBox.emit(this.user);
  }

  mover(){
    //console.log("Mouseover called");
    this.isHidden = true;
  }

  mout(){
    //console.log("Mouseout called");
    this.isHidden = false;
  }

  remove(){
    this.removeChatBox.emit(this.user);
  }

}
