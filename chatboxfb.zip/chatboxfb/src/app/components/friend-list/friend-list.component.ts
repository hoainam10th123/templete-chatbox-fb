import { Component, OnInit } from '@angular/core';
import { UserChatBox } from 'src/app/models/user-chatbox';

@Component({
  selector: 'app-friend-list',
  templateUrl: './friend-list.component.html',
  styleUrls: ['./friend-list.component.css']
})
export class FriendListComponent implements OnInit {

  usersOnline: UserChatBox[] = [];
  miniUser:UserChatBox[] = [];

  dataUser = [
    {userName: 'hoainam10th', displayName:'Nguyen Hoai Nam'},
    {userName: 'ubuntu', displayName:'Tran Hoai Nam'},
    {userName: 'lisa', displayName:'Nguyen Minh Bac'},
    {userName: 'tony', displayName:'Nguyen Hoai Phong'},
    {userName: 'agutech', displayName:'Technology'},
    {userName: 'android', displayName:'Android 11'}
  ]

  constructor() { }

  ngOnInit(): void {    
  }

  selectUser(user: any) {
    switch ((this.usersOnline.length+1) % 2) {
      case 1: {
        var u = this.usersOnline.find(x => x.user.userName === user.userName);
        if (u) {
          this.usersOnline = this.usersOnline.filter(x => x.user.userName !== user.userName);
          this.usersOnline.push(u);
        } else {
          this.usersOnline.push(new UserChatBox(user, 250));
        }        
        break;
      }
      case 0: {
        var u = this.usersOnline.find(x => x.user.userName === user.userName);
        if (u) {
          this.usersOnline = this.usersOnline.filter(x => x.user.userName !== user.userName);
          this.usersOnline.push(u);
        } else {
          this.usersOnline.push(new UserChatBox(user, 250 + 325));
        }
        break;
      }
      default: {
        console.log("No");
        break;
      }
    }
  }

  removeChatBox(event: string) {
    this.usersOnline = this.usersOnline.filter(x => x.user.userName !== event);
  }

  miniChatBox(user: any){
    this.miniUser.push(new UserChatBox(user, 250));
  }

  restoreUser(user: UserChatBox){
    this.miniUser = this.miniUser.filter(x => x.user.userName !== user.user.userName);
    this.selectUser(user.user);
  }

  removeMiniUser(user: any){
    this.miniUser = this.miniUser.filter(x => x.user.userName !== user.user.userName);
  }
}
