export class UserChatBox{
    user: any;
    right: number;//position

    constructor(_user: any, _right: number){
        this.user = _user;
        this.right = _right;
    }
}