import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChatboxComponent } from './components/chatbox/chatbox.component';
import { FriendListComponent } from './components/friend-list/friend-list.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MiniChatboxComponent } from './components/mini-chatbox/mini-chatbox.component';

@NgModule({
  declarations: [
    AppComponent,
    ChatboxComponent,
    FriendListComponent,
    MiniChatboxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
